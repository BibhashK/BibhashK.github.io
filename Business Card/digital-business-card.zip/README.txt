A Pen created at CodePen.io. You can find this one at http://codepen.io/willalanjohnson/pen/epRbvb.

 Save some trees! Make a digital business card!